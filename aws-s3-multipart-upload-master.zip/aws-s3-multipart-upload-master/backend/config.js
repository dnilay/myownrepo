exports.globals = {
    "AWS-BUCKET-NAME": "<AWS-BUCKET-NAME>", // Replace with your bucket 
    "ACCESS-ID": "<ACCESS-ID>", // Replace with your access key id 
    "AWS-SECRET-KEY": "<AWS-SECRET-KEY>", // Replace with your secret access key 
    "VERSION": "v4" 
}