#  aws-s3-presignurl-sts-assumerole

# Youtube Video Link: https://youtu.be/e8BVM-Hu76w
